# CricketScorecard

How to Use

#1 Clone the Repository
#2 composer install (Make sure Laravel is in latest version 5+)
#3 Create a database (make sure to change .env file)
#4 php artisan migrate
#5 php artisan serve
#6 npm run watch (optional)