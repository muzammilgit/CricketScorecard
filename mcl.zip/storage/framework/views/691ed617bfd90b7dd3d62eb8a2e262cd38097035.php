<?php $__env->startSection('content'); ?>
    <div id="wrapper">

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="clearfix"></div>

        <div class="content-wrapper">
            <div class="container-fluid">

                <!--Start Dashboard Content-->
                <div class="row pt-2 pb-2">
                    <div class="col-sm-9">
                        <h4 class="page-title">Teams</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javaScript:void(0);">MCL</a></li>
                            <li class="breadcrumb-item"><a href="javaScript:void(0);">Teams</a></li>
                        </ol>
                    </div>
                    <div class="col-sm-3">
                        <div class="btn-group float-sm-right">
                            <button type="button" class="btn btn-outline-primary waves-effect waves-light"><i
                                        class="fa fa-cog mr-1"></i>
                            </button>
                            <button type="button"
                                    class="btn btn-outline-primary waves-effect waves-light">
                                <a href="<?php echo e(url('/teams/new')); ?>">Add New Team</a>
                            </button>
                        </div>
                    </div>
                </div>
                <!-- End Breadcrumb-->
                <?php if(!isset($newTeam)): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header"><i class="fa fa-table"></i> Data Table Example</div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="default-datatable" class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Details</th>
                                                <th>Date</th>
                                                <th>Edit</th>
                                                <th>Delete</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($team->team_name); ?></td>
                                                    <td><?php echo e($team->created_at); ?></td>
                                                    <td><?php echo e($team->team_name); ?></td>
                                                    <td><a href="<?php echo e(url('/teams/edit/'.$team->id)); ?>"><i
                                                                    class="fa fa-pencil" aria-hidden="true"></i></a>
                                                    </td>
                                                    <td><a href="<?php echo e(url('teams/delete/'.$team->id)); ?>"><i
                                                                    class="fa fa-trash" aria-hidden="true"></i></a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Details</th>
                                                <th>Date</th>
                                                <th>Edit</th>
                                                <th>Delete</th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Row-->
                <?php endif; ?>

                <?php if(isset($newTeam) && $newTeam): ?>
                    <div class="row">
                        <div class="col-lg-10 mx-auto">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title">Add Team</div>
                                    <hr>
                                    <form action="<?php echo e((isset($team->team_name)) ? url('/teams/edit/'.$team->id) : url('/teams/new')); ?>"
                                          method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="input-1">Name</label>
                                            <input type="text" class="form-control" name="name" id="input-1"
                                                   placeholder="Enter Your Name" value="<?php echo e($team->team_name ?? ''); ?>">
                                            <?php if($errors->has('name')): ?>
                                                <span>
                                                    <strong class="invalid"><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="input-2">Email</label>
                                            <input type="text" class="form-control" name="email" id="input-2"
                                                   placeholder="Enter Your Email Address">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">Details</label>
                                            <input type="text" class="form-control" name="details" id="input-3"
                                                   placeholder="Enter Password">
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary shadow-primary px-5"><i
                                                        class="icon-lock"></i> Submit
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>


                    <!--End Dashboard Content-->

                    </div>
                    <!-- End container-fluid-->

            </div><!--End content-wrapper-->
            <!--Start Back To Top Button-->
            <a href="javaScript:void(0);" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
            <!--End Back To Top Button-->

            <!--Start footer-->
            <footer class="footer">
                <div class="container">
                    <div class="text-center">
                        Copyright © 2018 Rocker Admin
                    </div>
                </div>
            </footer>
            <!--End footer-->

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>